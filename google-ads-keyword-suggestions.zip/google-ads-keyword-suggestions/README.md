# Google Ads Keyword Suggestions

A WordPress plugin that integrates with the Google Ads API to provide real-time keyword suggestions while writing blog posts, helping content creators optimize their SEO strategy.

## Features

- 🔍 **Real-time Keyword Suggestions** - Get keyword ideas from Google Ads Keyword Planner directly in the WordPress editor
- 📊 **Keyword Metrics** - View monthly search volume, competition level, and estimated CPC for each keyword
- ✏️ **One-Click Insert** - Insert keywords into your content or add them as tags with a single click
- 🎯 **Geographic Targeting** - Configure target location and language for localized keyword suggestions
- 🔐 **Secure OAuth 2.0** - Industry-standard authentication with Google Ads API

## Requirements

- WordPress 5.8 or higher
- PHP 7.4 or higher
- Google Ads Manager Account with approved Developer Token
- Google Cloud Project with Google Ads API enabled
- OAuth 2.0 credentials (Client ID, Client Secret, Refresh Token)

## Installation

1. Download the plugin ZIP file or clone this repository
2. Upload to `/wp-content/plugins/google-ads-keyword-suggestions/`
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Go to **Settings → Keyword Suggestions** to configure your API credentials

## Configuration

### Getting Your API Credentials

1. **Developer Token**
   - Log in to your Google Ads Manager account
   - Go to Tools & Settings → API Center
   - Apply for a Developer Token (basic access is usually sufficient)

2. **OAuth 2.0 Credentials**
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select existing
   - Enable the Google Ads API
   - Go to APIs & Services → Credentials
   - Create OAuth 2.0 Client ID (Web application or Desktop app)
   - Note your Client ID and Client Secret

3. **Refresh Token**
   - Use the [OAuth Playground](https://developers.google.com/oauthplayground/) or
   - Download the [Google Ads API PHP examples](https://github.com/googleads/google-ads-php) and run `AuthenticateInStandaloneApplication.php`

4. **Customer ID**
   - Your Google Ads account number (found in the top right of Google Ads)
   - Format: 123-456-7890 (with or without dashes)

### Plugin Settings

Navigate to **Settings → Keyword Suggestions** and enter:

- Developer Token
- OAuth Client ID
- OAuth Client Secret
- Refresh Token
- Customer ID
- Target Location (default: United States)
- Target Language (default: English)

Click **Test Connection** to verify your credentials.

## Usage

1. Create or edit a post/page in WordPress
2. Click the puzzle piece icon in the top toolbar to open the Keyword Suggestions sidebar
3. Enter seed keywords (comma or newline separated)
4. Click **Get Suggestions**
5. Browse the keyword suggestions with their metrics
6. Click **Insert** to add a keyword to your content
7. Click **Add Tag** to add a keyword as a post tag

## Screenshots

### Settings Page
The settings page features a modern card-based interface for managing your API credentials.

### Editor Sidebar
The Gutenberg sidebar displays keyword suggestions with:
- Monthly search volume
- Competition level (Low/Medium/High)
- Estimated CPC range
- Quick action buttons

## Troubleshooting

### "Connection failed" error
- Verify all credentials are entered correctly
- Check that your Developer Token is approved
- Ensure the Google Ads API is enabled in your Cloud project

### No suggestions returned
- Try different seed keywords
- Check your Google Ads account has Keyword Planner access
- Verify your developer token tier has sufficient quota

### Rate limiting
- Basic developer tokens have ~15,000 requests/day limit
- Consider caching suggestions or reducing request frequency

## Security

- All credentials are stored in WordPress options table
- Credentials are encrypted in the database if using a security plugin
- Access tokens are cached using WordPress transients
- REST endpoints require `edit_posts` capability

## License

GPL v2 or later

## Support

For issues and feature requests, please use the GitHub issue tracker.

## Changelog

### 1.0.0
- Initial release
- Google Ads API integration for keyword suggestions
- Gutenberg sidebar panel
- Settings page with test connection feature
- One-click keyword insertion
