<?php
/**
 * Setup Guide page for the plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class GAKS_Setup_Guide {
    
    /**
     * Render the setup guide page
     */
    public static function render_page() {
        $current_step = isset($_GET['step']) ? intval($_GET['step']) : 1;
        ?>
        <div class="wrap gaks-setup-wrap">
            <h1>
                <span class="dashicons dashicons-welcome-learn-more"></span>
                <?php _e('Keyword Suggestions Setup Guide', 'google-ads-keyword-suggestions'); ?>
            </h1>
            
            <div class="gaks-setup-container">
                <!-- Progress Steps -->
                <div class="gaks-progress-bar">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <div class="gaks-progress-step <?php echo $i <= $current_step ? 'completed' : ''; ?> <?php echo $i === $current_step ? 'active' : ''; ?>">
                            <div class="step-number"><?php echo $i; ?></div>
                            <div class="step-label">
                                <?php
                                switch ($i) {
                                    case 1: _e('Google Cloud', 'google-ads-keyword-suggestions'); break;
                                    case 2: _e('Enable API', 'google-ads-keyword-suggestions'); break;
                                    case 3: _e('OAuth Setup', 'google-ads-keyword-suggestions'); break;
                                    case 4: _e('Developer Token', 'google-ads-keyword-suggestions'); break;
                                    case 5: _e('Configure Plugin', 'google-ads-keyword-suggestions'); break;
                                }
                                ?>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
                
                <!-- Step Content -->
                <div class="gaks-step-content">
                    <?php
                    switch ($current_step) {
                        case 1:
                            self::render_step_1();
                            break;
                        case 2:
                            self::render_step_2();
                            break;
                        case 3:
                            self::render_step_3();
                            break;
                        case 4:
                            self::render_step_4();
                            break;
                        case 5:
                            self::render_step_5();
                            break;
                        default:
                            self::render_step_1();
                    }
                    ?>
                </div>
                
                <!-- Navigation -->
                <div class="gaks-step-nav">
                    <?php if ($current_step > 1): ?>
                        <a href="<?php echo admin_url('admin.php?page=gaks-setup-guide&step=' . ($current_step - 1)); ?>" class="button button-secondary">
                            ← <?php _e('Previous Step', 'google-ads-keyword-suggestions'); ?>
                        </a>
                    <?php else: ?>
                        <span></span>
                    <?php endif; ?>
                    
                    <?php if ($current_step < 5): ?>
                        <a href="<?php echo admin_url('admin.php?page=gaks-setup-guide&step=' . ($current_step + 1)); ?>" class="button button-primary">
                            <?php _e('Next Step', 'google-ads-keyword-suggestions'); ?> →
                        </a>
                    <?php else: ?>
                        <a href="<?php echo admin_url('options-general.php?page=gaks-settings'); ?>" class="button button-primary">
                            <?php _e('Go to Settings', 'google-ads-keyword-suggestions'); ?> →
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Step 1: Create Google Cloud Project
     */
    private static function render_step_1() {
        ?>
        <div class="gaks-step-card">
            <h2>
                <span class="step-badge">Step 1</span>
                <?php _e('Create a Google Cloud Project', 'google-ads-keyword-suggestions'); ?>
            </h2>
            
            <div class="gaks-info-box">
                <span class="dashicons dashicons-info-outline"></span>
                <p><?php _e('You need a Google Cloud project to access the Google Ads API. This is free to create.', 'google-ads-keyword-suggestions'); ?></p>
            </div>
            
            <div class="gaks-instructions">
                <h3><?php _e('Instructions:', 'google-ads-keyword-suggestions'); ?></h3>
                
                <ol class="gaks-steps-list">
                    <li>
                        <strong><?php _e('Go to Google Cloud Console', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Open', 'google-ads-keyword-suggestions'); ?> <a href="https://console.cloud.google.com/" target="_blank">console.cloud.google.com</a> <?php _e('and sign in with your Google account.', 'google-ads-keyword-suggestions'); ?></p>
                        <div class="gaks-screenshot-placeholder">
                            <span class="dashicons dashicons-desktop"></span>
                            <span><?php _e('Google Cloud Console Homepage', 'google-ads-keyword-suggestions'); ?></span>
                        </div>
                    </li>
                    
                    <li>
                        <strong><?php _e('Create a New Project', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Click the project dropdown at the top of the page, then click "New Project".', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Name Your Project', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Enter a name like "WordPress Keyword Suggestions" and click "Create".', 'google-ads-keyword-suggestions'); ?></p>
                        <div class="gaks-tip">
                            <span class="dashicons dashicons-lightbulb"></span>
                            <span><?php _e('Tip: Use a descriptive name so you can easily identify this project later.', 'google-ads-keyword-suggestions'); ?></span>
                        </div>
                    </li>
                    
                    <li>
                        <strong><?php _e('Wait for Project Creation', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('The project will be created in a few seconds. Make sure it\'s selected in the project dropdown.', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                </ol>
            </div>
            
            <div class="gaks-action-box">
                <a href="https://console.cloud.google.com/projectcreate" target="_blank" class="button button-hero">
                    <span class="dashicons dashicons-external"></span>
                    <?php _e('Open Google Cloud Console', 'google-ads-keyword-suggestions'); ?>
                </a>
            </div>
        </div>
        <?php
    }
    
    /**
     * Step 2: Enable Google Ads API
     */
    private static function render_step_2() {
        ?>
        <div class="gaks-step-card">
            <h2>
                <span class="step-badge">Step 2</span>
                <?php _e('Enable the Google Ads API', 'google-ads-keyword-suggestions'); ?>
            </h2>
            
            <div class="gaks-info-box">
                <span class="dashicons dashicons-info-outline"></span>
                <p><?php _e('You need to enable the Google Ads API for your project to access keyword data.', 'google-ads-keyword-suggestions'); ?></p>
            </div>
            
            <div class="gaks-instructions">
                <h3><?php _e('Instructions:', 'google-ads-keyword-suggestions'); ?></h3>
                
                <ol class="gaks-steps-list">
                    <li>
                        <strong><?php _e('Go to API Library', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('In Google Cloud Console, go to "APIs & Services" → "Library" from the left menu.', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Search for Google Ads API', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Type "Google Ads API" in the search box and click on it when it appears.', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Enable the API', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Click the blue "Enable" button on the Google Ads API page.', 'google-ads-keyword-suggestions'); ?></p>
                        <div class="gaks-warning">
                            <span class="dashicons dashicons-warning"></span>
                            <span><?php _e('Important: Make sure you\'re enabling "Google Ads API", not "Google Ads Data Hub API" or similar.', 'google-ads-keyword-suggestions'); ?></span>
                        </div>
                    </li>
                    
                    <li>
                        <strong><?php _e('Verify Activation', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('After enabling, you should see "API enabled" with usage metrics. You can proceed to the next step.', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                </ol>
            </div>
            
            <div class="gaks-action-box">
                <a href="https://console.cloud.google.com/apis/library/googleads.googleapis.com" target="_blank" class="button button-hero">
                    <span class="dashicons dashicons-external"></span>
                    <?php _e('Enable Google Ads API', 'google-ads-keyword-suggestions'); ?>
                </a>
            </div>
        </div>
        <?php
    }
    
    /**
     * Step 3: Create OAuth Credentials
     */
    private static function render_step_3() {
        ?>
        <div class="gaks-step-card">
            <h2>
                <span class="step-badge">Step 3</span>
                <?php _e('Create OAuth 2.0 Credentials', 'google-ads-keyword-suggestions'); ?>
            </h2>
            
            <div class="gaks-info-box info">
                <span class="dashicons dashicons-info-outline"></span>
                <p><?php _e('OAuth credentials allow your WordPress site to securely access Google Ads on your behalf.', 'google-ads-keyword-suggestions'); ?></p>
            </div>
            
            <div class="gaks-instructions">
                <h3><?php _e('Part A: Configure Consent Screen', 'google-ads-keyword-suggestions'); ?></h3>
                
                <ol class="gaks-steps-list">
                    <li>
                        <strong><?php _e('Go to OAuth Consent Screen', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Navigate to "APIs & Services" → "OAuth consent screen".', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Choose User Type', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Select "External" (allows any Google account) and click "Create".', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Fill App Information', 'google-ads-keyword-suggestions'); ?></strong>
                        <ul>
                            <li><?php _e('App name: "WordPress Keyword Suggestions"', 'google-ads-keyword-suggestions'); ?></li>
                            <li><?php _e('User support email: Your email', 'google-ads-keyword-suggestions'); ?></li>
                            <li><?php _e('Developer contact: Your email', 'google-ads-keyword-suggestions'); ?></li>
                        </ul>
                        <p><?php _e('Click "Save and Continue" through the remaining screens.', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                </ol>
                
                <h3><?php _e('Part B: Create OAuth Client ID', 'google-ads-keyword-suggestions'); ?></h3>
                
                <ol class="gaks-steps-list" start="4">
                    <li>
                        <strong><?php _e('Go to Credentials', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Navigate to "APIs & Services" → "Credentials".', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Create OAuth Client ID', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Click "+ Create Credentials" → "OAuth client ID".', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Configure the Client', 'google-ads-keyword-suggestions'); ?></strong>
                        <ul>
                            <li><?php _e('Application type: <strong>Desktop app</strong>', 'google-ads-keyword-suggestions'); ?></li>
                            <li><?php _e('Name: "WordPress Plugin"', 'google-ads-keyword-suggestions'); ?></li>
                        </ul>
                        <p><?php _e('Click "Create".', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Save Your Credentials', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('A popup will show your <strong>Client ID</strong> and <strong>Client Secret</strong>. Copy these somewhere safe!', 'google-ads-keyword-suggestions'); ?></p>
                        <div class="gaks-credentials-save">
                            <label><?php _e('Client ID:', 'google-ads-keyword-suggestions'); ?></label>
                            <input type="text" id="save-client-id" placeholder="<?php _e('Paste your Client ID here to save', 'google-ads-keyword-suggestions'); ?>">
                            <label><?php _e('Client Secret:', 'google-ads-keyword-suggestions'); ?></label>
                            <input type="password" id="save-client-secret" placeholder="<?php _e('Paste your Client Secret here to save', 'google-ads-keyword-suggestions'); ?>">
                        </div>
                    </li>
                </ol>
                
                <h3><?php _e('Part C: Generate Refresh Token', 'google-ads-keyword-suggestions'); ?></h3>
                
                <ol class="gaks-steps-list" start="8">
                    <li>
                        <strong><?php _e('Use OAuth Playground', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Open', 'google-ads-keyword-suggestions'); ?> <a href="https://developers.google.com/oauthplayground/" target="_blank">OAuth 2.0 Playground</a></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Configure Settings', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Click the gear icon (⚙️) in the top right and check "Use your own OAuth credentials". Enter your Client ID and Client Secret.', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Select Scope', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('In the left panel, scroll down and select "Google Ads API v17" → check the scope:', 'google-ads-keyword-suggestions'); ?></p>
                        <code class="gaks-code-block">https://www.googleapis.com/auth/adwords</code>
                        <p><?php _e('Click "Authorize APIs".', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Authorize & Get Tokens', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Sign in with your Google account, grant permissions, then click "Exchange authorization code for tokens".', 'google-ads-keyword-suggestions'); ?></p>
                        <p><?php _e('Copy the <strong>Refresh token</strong> value.', 'google-ads-keyword-suggestions'); ?></p>
                        <div class="gaks-credentials-save">
                            <label><?php _e('Refresh Token:', 'google-ads-keyword-suggestions'); ?></label>
                            <input type="password" id="save-refresh-token" placeholder="<?php _e('Paste your Refresh Token here to save', 'google-ads-keyword-suggestions'); ?>">
                        </div>
                    </li>
                </ol>
            </div>
            
            <div class="gaks-action-box">
                <a href="https://console.cloud.google.com/apis/credentials" target="_blank" class="button button-hero">
                    <span class="dashicons dashicons-external"></span>
                    <?php _e('Open Credentials Page', 'google-ads-keyword-suggestions'); ?>
                </a>
                <a href="https://developers.google.com/oauthplayground/" target="_blank" class="button button-secondary button-hero">
                    <span class="dashicons dashicons-external"></span>
                    <?php _e('Open OAuth Playground', 'google-ads-keyword-suggestions'); ?>
                </a>
            </div>
        </div>
        <?php
    }
    
    /**
     * Step 4: Get Developer Token
     */
    private static function render_step_4() {
        ?>
        <div class="gaks-step-card">
            <h2>
                <span class="step-badge">Step 4</span>
                <?php _e('Get Your Developer Token', 'google-ads-keyword-suggestions'); ?>
            </h2>
            
            <div class="gaks-info-box warning">
                <span class="dashicons dashicons-warning"></span>
                <p><?php _e('You need a Google Ads Manager Account (MCC) to get a developer token. If you don\'t have one, you\'ll need to create it first.', 'google-ads-keyword-suggestions'); ?></p>
            </div>
            
            <div class="gaks-instructions">
                <h3><?php _e('Instructions:', 'google-ads-keyword-suggestions'); ?></h3>
                
                <ol class="gaks-steps-list">
                    <li>
                        <strong><?php _e('Access Google Ads', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Go to', 'google-ads-keyword-suggestions'); ?> <a href="https://ads.google.com" target="_blank">ads.google.com</a> <?php _e('and sign in.', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Create Manager Account (if needed)', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('If you don\'t have a Manager Account:', 'google-ads-keyword-suggestions'); ?></p>
                        <ul>
                            <li><?php _e('Go to', 'google-ads-keyword-suggestions'); ?> <a href="https://ads.google.com/home/tools/manager-accounts/" target="_blank"><?php _e('Manager Accounts', 'google-ads-keyword-suggestions'); ?></a></li>
                            <li><?php _e('Click "Create a manager account"', 'google-ads-keyword-suggestions'); ?></li>
                            <li><?php _e('Follow the setup wizard', 'google-ads-keyword-suggestions'); ?></li>
                        </ul>
                    </li>
                    
                    <li>
                        <strong><?php _e('Go to API Center', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('In your Manager Account, click "Tools & Settings" (wrench icon) → "API Center" under "Setup".', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Apply for Developer Token', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('If you don\'t have a token yet, apply for "Basic Access". This is usually approved within a few days.', 'google-ads-keyword-suggestions'); ?></p>
                        <div class="gaks-tip">
                            <span class="dashicons dashicons-lightbulb"></span>
                            <span><?php _e('For testing, you can use a Test Account which has immediate access.', 'google-ads-keyword-suggestions'); ?></span>
                        </div>
                    </li>
                    
                    <li>
                        <strong><?php _e('Copy Developer Token', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Once approved, copy your Developer Token from the API Center page.', 'google-ads-keyword-suggestions'); ?></p>
                        <div class="gaks-credentials-save">
                            <label><?php _e('Developer Token:', 'google-ads-keyword-suggestions'); ?></label>
                            <input type="password" id="save-dev-token" placeholder="<?php _e('Paste your Developer Token here', 'google-ads-keyword-suggestions'); ?>">
                        </div>
                    </li>
                    
                    <li>
                        <strong><?php _e('Note Your Customer ID', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Your Customer ID is displayed in the top right corner of Google Ads (format: XXX-XXX-XXXX).', 'google-ads-keyword-suggestions'); ?></p>
                        <div class="gaks-credentials-save">
                            <label><?php _e('Customer ID:', 'google-ads-keyword-suggestions'); ?></label>
                            <input type="text" id="save-customer-id" placeholder="123-456-7890">
                        </div>
                    </li>
                </ol>
            </div>
            
            <div class="gaks-action-box">
                <a href="https://ads.google.com" target="_blank" class="button button-hero">
                    <span class="dashicons dashicons-external"></span>
                    <?php _e('Open Google Ads', 'google-ads-keyword-suggestions'); ?>
                </a>
            </div>
        </div>
        <?php
    }
    
    /**
     * Step 5: Configure Plugin
     */
    private static function render_step_5() {
        $settings = get_option('gaks_settings', array());
        $is_configured = GAKS_Admin::is_configured();
        ?>
        <div class="gaks-step-card">
            <h2>
                <span class="step-badge">Step 5</span>
                <?php _e('Configure the Plugin', 'google-ads-keyword-suggestions'); ?>
            </h2>
            
            <?php if ($is_configured): ?>
                <div class="gaks-info-box success">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <p><?php _e('Great news! Your plugin is already configured. You can start using keyword suggestions!', 'google-ads-keyword-suggestions'); ?></p>
                </div>
            <?php else: ?>
                <div class="gaks-info-box">
                    <span class="dashicons dashicons-info-outline"></span>
                    <p><?php _e('Now let\'s enter all the credentials you\'ve collected into the plugin settings.', 'google-ads-keyword-suggestions'); ?></p>
                </div>
            <?php endif; ?>
            
            <div class="gaks-instructions">
                <h3><?php _e('Credentials Checklist:', 'google-ads-keyword-suggestions'); ?></h3>
                
                <div class="gaks-checklist">
                    <label class="gaks-check-item <?php echo !empty($settings['developer_token']) ? 'checked' : ''; ?>">
                        <span class="dashicons <?php echo !empty($settings['developer_token']) ? 'dashicons-yes' : 'dashicons-marker'; ?>"></span>
                        <?php _e('Developer Token', 'google-ads-keyword-suggestions'); ?>
                    </label>
                    <label class="gaks-check-item <?php echo !empty($settings['client_id']) ? 'checked' : ''; ?>">
                        <span class="dashicons <?php echo !empty($settings['client_id']) ? 'dashicons-yes' : 'dashicons-marker'; ?>"></span>
                        <?php _e('OAuth Client ID', 'google-ads-keyword-suggestions'); ?>
                    </label>
                    <label class="gaks-check-item <?php echo !empty($settings['client_secret']) ? 'checked' : ''; ?>">
                        <span class="dashicons <?php echo !empty($settings['client_secret']) ? 'dashicons-yes' : 'dashicons-marker'; ?>"></span>
                        <?php _e('OAuth Client Secret', 'google-ads-keyword-suggestions'); ?>
                    </label>
                    <label class="gaks-check-item <?php echo !empty($settings['refresh_token']) ? 'checked' : ''; ?>">
                        <span class="dashicons <?php echo !empty($settings['refresh_token']) ? 'dashicons-yes' : 'dashicons-marker'; ?>"></span>
                        <?php _e('Refresh Token', 'google-ads-keyword-suggestions'); ?>
                    </label>
                    <label class="gaks-check-item <?php echo !empty($settings['customer_id']) ? 'checked' : ''; ?>">
                        <span class="dashicons <?php echo !empty($settings['customer_id']) ? 'dashicons-yes' : 'dashicons-marker'; ?>"></span>
                        <?php _e('Customer ID', 'google-ads-keyword-suggestions'); ?>
                    </label>
                </div>
                
                <h3><?php _e('Final Steps:', 'google-ads-keyword-suggestions'); ?></h3>
                
                <ol class="gaks-steps-list">
                    <li>
                        <strong><?php _e('Enter Credentials', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Go to Settings → Keyword Suggestions and enter all your credentials.', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Test Connection', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Click the "Test Connection" button to verify everything works.', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                    
                    <li>
                        <strong><?php _e('Start Using!', 'google-ads-keyword-suggestions'); ?></strong>
                        <p><?php _e('Create or edit a post, then open the Keyword Suggestions panel in the sidebar to get keyword ideas!', 'google-ads-keyword-suggestions'); ?></p>
                    </li>
                </ol>
            </div>
            
            <div class="gaks-action-box">
                <a href="<?php echo admin_url('options-general.php?page=gaks-settings'); ?>" class="button button-hero button-primary">
                    <span class="dashicons dashicons-admin-settings"></span>
                    <?php _e('Go to Plugin Settings', 'google-ads-keyword-suggestions'); ?>
                </a>
            </div>
            
            <?php if ($is_configured): ?>
                <div class="gaks-success-box">
                    <h3>🎉 <?php _e('You\'re all set!', 'google-ads-keyword-suggestions'); ?></h3>
                    <p><?php _e('Open any post in the block editor and click the Keyword Suggestions icon in the sidebar to start finding great keywords for your content!', 'google-ads-keyword-suggestions'); ?></p>
                    <a href="<?php echo admin_url('post-new.php'); ?>" class="button button-primary">
                        <?php _e('Create New Post', 'google-ads-keyword-suggestions'); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
